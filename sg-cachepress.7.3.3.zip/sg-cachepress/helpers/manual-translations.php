<?php
__( 'SuperCacher Settings', 'sg-cachepress' );
__( 'Environment Optimization', 'sg-cachepress' );
__( 'Frontend Optimization', 'sg-cachepress' );
__( 'Media Optimization', 'sg-cachepress' );
__( 'Performance Test', 'sg-cachepress' );
__( 'Caching', 'sg-cachepress' );
__( 'Environment', 'sg-cachepress' );
__( 'Frontend', 'sg-cachepress' );
__( 'Speed Test', 'sg-cachepress' );
__( 'Media', 'sg-cachepress' );
